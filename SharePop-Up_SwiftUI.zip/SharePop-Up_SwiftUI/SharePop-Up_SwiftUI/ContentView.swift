//
//  ContentView.swift
//  SharePop-Up_SwiftUI
//
//  Created by Immature Inc on 20/04/2020.
//  Copyright © 2020 AnthonyDesignCode.io. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    @State private var isShareSheetShowing = false
    
    var body: some View {
        Button(action: shareButton) {
            Image(systemName: "square.and.arrow.up")
                .font(.title)
                .foregroundColor(.black)
        }
    }
    
    func shareButton() {
        
        isShareSheetShowing.toggle()
        
        let url = URL(string: "https://youtu.be/EBc1OjRrJjs")
        let av = UIActivityViewController(activityItems: [url!], applicationActivities: nil)
        
        UIApplication.shared.windows.first?.rootViewController?.present(av, animated: true, completion: nil)

    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
